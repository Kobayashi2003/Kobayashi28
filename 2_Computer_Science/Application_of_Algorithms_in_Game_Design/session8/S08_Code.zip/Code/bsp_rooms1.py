#! /usr/bin/env python3
''' Show off BSP Tree algorithms. '''
import pygame, random
from pathlib import Path

def main():
    display_width  = 1024
    display_height = 768
    display_margin = 5
    min_room_width = 52
    min_room_height = 52
    min_room_spacing = 10
    min_leaf_width = min_room_width * 2
    min_leaf_height = min_room_height * 2
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('BSP Trees: With Fancy Rooms!')
    
    iteration_depth = 2
    bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                  display_height-2*display_margin, iteration_depth, iteration_depth)

    stats_font = pygame.font.SysFont(['helvetica'], 18)
    stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))
    
    mouse = False
    while True:
        quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse = check_events(mouse)
        if quit:
            break            
        if print_it:
            bsp.print_it(iteration_depth)
        if plus:
            iteration_depth += 1
        if minus:
            iteration_depth = max(0, iteration_depth - 1)
        if new_it:
            bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                          display_height-2*display_margin, iteration_depth, iteration_depth)
            stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))
        if rooms and not bsp.has_room:
            bsp.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if newmouse:
            bsp.debug(mouse)
                           
        screen.fill((0,0,0))
        bsp.draw(screen)
        screen.blit(stats_surf,(display_margin+1, display_margin+1))
        pygame.display.flip()            

class Room:

    floor_surf = None
    
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        if not Room.floor_surf:
            current_directory = Path('.')
            Room.floor_surf = pygame.image.load(current_directory / 
                                                'assets' / 'floor.png')
            Room.vert_surf  = pygame.image.load(current_directory / 
                                                'assets' / 'wall_vertical.png')
            Room.horiz_surf = pygame.transform.rotate(Room.vert_surf, 90)
                
    def draw(self, surface):
        pygame.draw.rect(surface, (0,200,200), self.rect, width=1)
        self.draw_floor(surface)
        self.draw_walls(surface)
        self.draw_doors(surface)
        
    def draw_floor(self, surface):
        for x in range(self.rect.left + 10, self.rect.right - 10 - 31, 32):
            for y in range(self.rect.top + 10, self.rect.bottom - 10 - 31, 32):
                surface.blit(Room.floor_surf, (x, y))
            # clean up bottom row
            ytiles,yremain = divmod(self.rect.height - 20, 32)
            yrect = pygame.Rect(0, 0, 32, yremain)
            y = self.rect.top + 10 + ytiles * 32
            surface.blit(Room.floor_surf, (x,y), yrect)
        # clean up last column
        xtiles, xremain = divmod(self.rect.width - 20, 32)
        xrect = pygame.Rect(0, 0, xremain, 32)
        xlast_rect = pygame.Rect(0, 0, xremain, yremain)
        ylast_row  = y
        x = self.rect.left + 10 + xtiles * 32
        for y in range(self.rect.top + 10, self.rect.bottom - 10 - 31, 32):
            surface.blit(Room.floor_surf, (x, y), xrect)
        surface.blit(Room.floor_surf, (x, ylast_row), xlast_rect)
 
    def draw_walls(self, surface):
        self.draw_horizontal_walls(surface, self.rect.top)
        self.draw_horizontal_walls(surface, self.rect.bottom - 10)
        self.draw_vertical_walls(surface, self.rect.left)
        self.draw_vertical_walls(surface, self.rect.right - 10)
        
    def draw_horizontal_walls(self, surface, y):
        # Wall segment size is 10 x 35
        num_tiles, remaining = divmod(self.rect.width, 35)
        x = self.rect.left
        for _ in range(num_tiles):
            surface.blit(Room.horiz_surf, (x, y))
            x += 35
        rem_rect = pygame.Rect(0,0,remaining,10)
        surface.blit(Room.horiz_surf, (x, y), rem_rect)
        
    def draw_vertical_walls(self, surface, x):
        # Wall segment size is 10 x 35
        num_tiles, remaining = divmod(self.rect.height - 20, 35)
        y = self.rect.top + 10
        for _ in range(num_tiles):
            surface.blit(Room.vert_surf, (x, y))
            y += 35
        rem_rect = pygame.Rect(0,0,10,remaining)
        surface.blit(Room.vert_surf, (x, y), rem_rect)
        
        
    def draw_doors(self, surface):
        pass       
                
    def __str__(self):
        return f'Room at {self.rect}'
        
        
class BSPTree:

    def __init__(self, x, y, width, height, iterations, max_iterations):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)
        self.iteration_depth = iterations
        self.left = self.right = None
        self.room = None
        self.has_room = False
        if iterations > 0:
            self.split(iterations, max_iterations)
            
    def debug(self, pos):
        if self.rect.collidepoint(pos):
            if not self.left and not self.right:
                print(f'{self.room}')
            if self.left:
                self.left.debug(pos)
            if self.right:
                self.right.debug(pos)
            
    def generate_rooms(self, min_room_width, min_room_height, min_room_spacing):
        if self.left:
            self.left.generate_rooms(min_room_width, min_room_height, min_room_spacing)
            self.right.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if not self.left and not self.right:
            self.build_my_room(min_room_width, min_room_height, min_room_spacing)
        
    def build_my_room(self, min_room_width, min_room_height, min_room_spacing):
        width_ok  = self.width  > min_room_width  + 2 * min_room_spacing
        height_ok = self.height > min_room_height + 2 * min_room_spacing
        if width_ok and height_ok:
            room_width = random.randrange(min_room_width, self.width-2*min_room_spacing)
            room_x = random.randrange(min_room_spacing, 
                                      self.width-room_width - min_room_spacing)
            room_x += self.x
            room_height = random.randrange(min_room_height, self.height-2*min_room_spacing)
            room_y = random.randrange(min_room_spacing, 
                                      self.height-room_height - min_room_spacing)
            room_y += self.y
            self.room = Room(room_x, room_y, room_width, room_height)
            self.has_rooms = True

    def split(self, iterations, max_iterations):
        if iterations < max_iterations *.75 and random.random() < .1:
            return
        if self.width / self.height > 1.25:
            split_vertical = True
        elif self.height / self.width > 1.25:
            split_vertical = False
        else:
            split_vertical = random.random() < .5
            
        ratio_limit = .35
        if split_vertical:
            lower_w = round(self.width * ratio_limit)
            upper_w = round(self.width * (1-ratio_limit))
            w = random.randrange(lower_w, upper_w)
            self.left, self.right = self.make_siblings(True, w, iterations - 1, max_iterations)
        else:
            lower_h = round(self.height * ratio_limit)
            upper_h = round(self.height * (1-ratio_limit))
            h = random.randrange(lower_h, upper_h)
            self.left, self.right = self.make_siblings(False, h, iterations - 1, max_iterations)
                    
    def make_siblings(self, vertical, leftup, iterations, max_iterations):
        if vertical:
            left  = BSPTree(self.x, self.y, leftup, self.height, iterations, max_iterations)
            right = BSPTree(self.x + leftup, self.y, self.width - leftup, self.height, iterations, max_iterations)
        else:
            left  = BSPTree(self.x, self.y, self.width, leftup, iterations, max_iterations)
            right = BSPTree(self.x, self.y + leftup, self.width, self.height-leftup, iterations, max_iterations)
        return left, right
        
    def draw(self, surface):
        pygame.draw.rect(surface, (0,0,255), self.rect, width=1)
        if self.left:
            self.left.draw(surface)
            self.right.draw(surface)
        if self.room:
            self.room.draw(surface)
                
    def print_it(self, total_iterations):
        indent = '  ' * (total_iterations - self.iteration_depth)
        print(f'{indent}{self}')
        if self.left:
            self.left.print_it(total_iterations)
            self.right.print_it(total_iterations)
            
    def __str__(self):
        ret_val = f'BSPTree({self.x}, {self.y}, {self.width}, {self.height}'
        if self.left:
            ret_val += f', LR'
        
        if self.has_room:
            ret_val += ', Room({self.room_rect})'

        ret_val += ')'        
        return ret_val
    
def check_events(mouse):
    ''' A controller of sorts.  Looks for Quit, several simple events.
        Returns: True/False for if a Quit event happened.
    '''
    
    quit, print_it, new_it, plus, minus, rooms, hallways, newmouse = [False] * 8
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                quit = True
            if event.key == pygame.K_ESCAPE:
                quit = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_p:
                print_it = True
            if event.key == pygame.K_a:
                plus = True
            if event.key == pygame.K_z:
                minus = True
            if event.key == pygame.K_n:
                new_it = True
            if event.key == pygame.K_r:
                rooms = True
            if event.key == pygame.K_h:
                hallways = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            newmouse = mouse = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            mouse = False
                
    return quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse
            
if __name__ == "__main__":
    main()