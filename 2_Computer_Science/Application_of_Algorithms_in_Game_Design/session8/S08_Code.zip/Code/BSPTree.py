#! /usr/bin/env python3
''' A module for the Binary Space Partitioning Tree, tuned for use in room creation. '''
import random
from enum import Enum

class Side(Enum):
    LEFT = 1
    RIGHT = 2
    TOP = 3
    BOTTOM = 4
    
    @property
    def is_vertical(self):
        return self.value <= 2

    @property
    def is_horizontal(self):
        return self.value >= 3

class BSPTree:

    def __init__(self, x, y, width, height, iterations, max_iterations, split_side):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.iteration_depth = iterations
        self.left = self.right = None
        if iterations > 0:
            self.split(iterations, max_iterations)
        self.split_side = split_side

    def split(self, iterations, max_iterations):
        if iterations < max_iterations *.75 and random.random() < .1:
            return
        if self.width / self.height > 1.25:
            split_vertical = True
        elif self.height / self.width > 1.25:
            split_vertical = False
        else:
            split_vertical = random.random() < .5
            
        ratio_limit = .35
        if split_vertical:
            lower_w = round(self.width * ratio_limit)
            upper_w = round(self.width * (1-ratio_limit))
            w = random.randrange(lower_w, upper_w)
            self.left, self.right = self.make_siblings(True, w, iterations - 1, max_iterations)
        else:
            lower_h = round(self.height * ratio_limit)
            upper_h = round(self.height * (1-ratio_limit))
            h = random.randrange(lower_h, upper_h)
            self.left, self.right = self.make_siblings(False, h, iterations - 1, max_iterations)
                    
    def make_siblings(self, vertical, leftup, iterations, max_iterations):
        if vertical:
            left  = BSPTree(self.x, self.y, leftup, self.height,  
                            iterations, max_iterations, Side.RIGHT)
            right = BSPTree(self.x + leftup, self.y, self.width - leftup, self.height, 
                            iterations, max_iterations, Side.LEFT)
        else:
            left  = BSPTree(self.x, self.y, self.width, leftup,  
                            iterations, max_iterations, Side.BOTTOM)
            right = BSPTree(self.x, self.y + leftup, self.width, self.height-leftup,  
                            iterations, max_iterations, Side.TOP)
        return left, right
            
    def print_it(self, total_iterations):
        indent = '  ' * (total_iterations - self.iteration_depth)
        print(f'{indent}BSPTree({self.x}, {self.y}, {self.width}, {self.height})')
        if self.left:
            self.left.print_it(total_iterations)
        if self.right:
            self.right.print_it(total_iterations)
              