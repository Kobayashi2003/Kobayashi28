#! /usr/bin/env python3
''' Run cool maze generating algorithms. '''
import random
import BSPTree

class Cell:
    ''' Represents a single cell of a maze.  Cells know their neighbors
        and know if they are linked (connected) to each.  Cells have
        four potential neighbors, in NSEW directions.
    '''  
    def __init__(self, row, column):
        assert row >= 0
        assert column >= 0
        self.row = row
        self.column = column
        self.links = {}
        self.north = None
        self.south = None
        self.east  = None
        self.west  = None
        
    def link(self, cell, bidirectional=True):
        ''' Carve a connection to another cell (i.e. the maze connects them)'''
        assert isinstance(cell, Cell)
        self.links[cell] = True
        if bidirectional:
            cell.link(self, bidirectional=False)
        
    def unlink(self, cell, bidirectional=True):
        ''' Remove a connection to another cell (i.e. the maze 
            does not connect the two cells)
            
            Argument bidirectional is here so that I can call unlink on either
            of the two cells and both will be unlinked.
        '''
        assert isinstance(cell, Cell)
        del self.links[cell]
        if bidirectional:
            cell.unlink(self, bidirectional=False)
            
    def is_linked(self, cell):
        ''' Test if this cell is connected to another cell.
            
            Returns: True or False
        '''
        if cell:
            return self.links.get(cell, False)
        return False
        
    def all_links(self):
        ''' Return a list of all cells that we are connected to.'''
        return self.links.keys()
        
    def link_count(self):
        ''' Return the number of cells that we are connected to.'''
        return len(self.links)
        
    def is_deadend(self):
        ''' A deadend cell is only linked to one neighbor'''
        return len(self.links) == 1
    
    def neighbors(self):
        ''' Return a list of all geographical neighboring cells, regardless
            of any connections.  Only returns actual cells, never a None.
        '''
        list = [self.north, self.south, self.east, self.west]
        return [x for x in list if x]
                
    def __str__(self):
        return f'Cell at {self.row}, {self.column}'
        
    def extended_str(self):
        ret_val = f'Cell at {self.row}, {self.column}\n'
        ret_val += f'  Neighbors (NSEW): {self.north}, {self.south}, {self.east}, {self.west}\n'
        link_str = ''
        if self.is_linked(self.north):
            link_str = 'North'
        if self.is_linked(self.south):
            link_str += 'South'
        if self.is_linked(self.east):
            link_str += 'East'
        if self.is_linked(self.west):
            link_str += 'West'
        if not link_str:
            link_str = 'None'         
        ret_val += f'  Linked to: {link_str}'
        return ret_val
        
class Room(Cell):
    ''' A single cell that will actually take up many cell's space in the
        grid.  It represents a room in a maze/dungeon.
        
        On each side, it will physically have multiple neighbors.  However,
        only one of those will be a "real" neighbor -- and it will be randomly
        chosen.  The rest will have directional attributes pointing towards the
        room set to None.
    '''
    
    def __init__(self, row, col, width, height):
        assert width > 1
        assert height > 1
        super().__init__(row, col)
        self.width = width
        self.height = height
        self.neighbor_index_top    = random.randrange(1, width - 1)
        self.neighbor_index_bottom = random.randrange(1, width - 1)
        self.neighbor_index_left   = random.randrange(1, height - 1)
        self.neighbor_index_right  = random.randrange(1, height - 1)
        
    def __str__(self):
        return f'Room: {self.row}, {self.column}, {self.width}, {self.height}'       

    def extended_str(self):
        ret_val = f'Room: {self.row}, {self.column}, {self.width}, {self.height}\n'
        ret_val += f'  Neighbors (NSEW): {self.north}, {self.south}, {self.east}, {self.west}\n'
        ret_val += f'  Neighbor Indexes: {self.neighbor_index_top}, {self.neighbor_index_bottom}, {self.neighbor_index_left}, {self.neighbor_index_right}\n'
        link_str = ''
        if self.is_linked(self.north):
            link_str = 'North'
        if self.is_linked(self.south):
            link_str += 'South'
        if self.is_linked(self.east):
            link_str += 'East'
        if self.is_linked(self.west):
            link_str += 'West'
        if not link_str:
            link_str = 'None'         
        ret_val += f'  Linked to: {link_str}'
        return ret_val

class Grid:
    ''' A container to hold all the cells in a maze. The grid is a 
        rectangular collection, with equal numbers of columns in each
        row and vis versa.
    '''
    
    def __init__(self, num_rows, num_columns):
        assert num_rows > 0
        assert num_columns > 0
        self.num_rows = num_rows
        self.num_columns = num_columns
        self.grid = self.create_cells()
        self.connect_cells()
        
    def create_cells(self):
        ''' Call the cells into being.  Keep track of them in a list
            for each row and a list of all rows (i.e. a 2d list-of-lists).
            
            Do not connect the cells, as their neighbors may not yet have
            been created.
        '''
        grid = []
        for row in range(self.num_rows):
            r = []
            for col in range(self.num_columns):
                r.append(Cell(row, col))
            grid.append(r)
        return grid
            
    def connect_cells(self):
        ''' Now that all the cells have been created, connect them to 
            each other. 
        '''
        for cell in self.each_cell():
            row = cell.row
            col = cell.column
            cell.north = self.cell_at(row-1,col)
            cell.south = self.cell_at(row+1,col)
            cell.east  = self.cell_at(row,col+1)
            cell.west  = self.cell_at(row,col-1)
        
    def cell_at(self, row, column):
        ''' Retrieve the cell at a particular row/column index.'''
        if row < 0 or row >= self.num_rows:
            return None
        if column < 0 or column >= self.num_columns:
            return None
        return self.grid[row][column]
        
    def deadends(self):
        ''' Return a list of all cells that are deadends (i.e. only link to
            one other cell).
        '''
        deads = []
        for cell in self.each_cell():
            if cell.is_deadend():
                deads.append(cell)
        return deads
        
    def braid(self, prob=1.0):
        ''' A braided maze has loops.  We can create a braided maze by simply
            linking deadend cells to a random neighbor.
            
            An optimization is to link a deadend cell to a deadend neighbor, if
            one exists.
            
            Arguments: prob -- this is the probability that each cell will 
                       be braided.  At the default value, all deadends will
                       be linked, thus the result is a maze entirely without 
                       deadends.  Other values between 0 and 1 lead to mazes
                       with various levels of braiding.'''
        assert prob >= 0.0
        assert prob <= 1.0
        num_braided = 0
        num_best = 0
        num_deads = len(self.deadends())
        if num_deads == 0:
            return  # maze algorithm hasn't been run yet.  Can't braid what isn't here
        for c in self.deadends():
            if not c.is_deadend():  #could have been linked to in a previous iteration
                continue
            if random.random() > prob:
                continue
            neighbors_not_linked = [n 
                                    for n in c.neighbors() 
                                    if not c.is_linked(n)
                                   ]
            best = [n
                    for n in neighbors_not_linked
                    if n.is_deadend()]
            if best:
                chosen = random.choice(best)
                num_best += 1
            else:
                chosen = random.choice(neighbors_not_linked)
            c.link(chosen, bidirectional=True)
            num_braided += 1
        print(f'Braided {num_braided} out of {num_deads} deadend cells.')
        print(f'  Percentage is {num_braided / num_deads}.')
        print(f'  Best optimization used {num_best} times.')            
                            
    def each_cell(self):
        ''' A generator.  Each time it is called, it will return one of 
            the cells in the grid.
        '''
        for row in range(self.num_rows):
            for col in range(self.num_columns):
                c = self.cell_at(row, col)
                yield c
                
    def random_cell(self):
        ''' Chose one of the cells in an independent, uniform distribution. '''
        random_row    = random.randrange(self.num_rows)
        random_column = random.randrange(self.num_columns)
        return self.cell_at(random_row, random_column)
        
    def size(self):
        ''' How many cells are in the grid? '''
        return self.num_rows * self.num_columns
        
    def set_markup(self, markup):
        ''' Warning: this is a hack.
            Keep track of a markup, for use in representing the grid
            as a string.  It is used in the __str__ function and probably
            shouldn't be used elsewhere.
        '''
        self.markup = markup
        
    def report(self):
        print(f'Regular grid.  Nothing to report')
        
    def __str__(self):
        ret_val = '+' + '---+' * self.num_columns + '\n'
        for row in self.grid:
            ret_val += '|'
            for cell in row:
                cell_value = self.markup[cell]
                ret_val += '{:^3s}'.format(str(cell_value))
                if not cell.east:
                    ret_val += '|'
                elif cell.east.is_linked(cell):
                    ret_val += ' '
                else:
                    ret_val += '|'
            ret_val += '\n+'
            for cell in row:
                if not cell.south:
                    ret_val += '---+'
                elif cell.south.is_linked(cell):
                    ret_val += '   +'
                else:
                    ret_val += '---+'
            ret_val += '\n'
        return ret_val

class Grid_with_Rooms(Grid):

    def __init__(self, num_rows, num_columns, min_room_width, min_room_height, min_room_spacing):
        super().__init__(num_rows, num_columns)
        self.min_room_width = min_room_width
        self.min_room_height = min_room_height
        self.min_room_spacing = min_room_spacing

    def each_cell(self):
        ''' A generator.  Each time it is called, it will return one of 
            the cells in the grid.
        '''
        for row in range(self.num_rows):
            for col in range(self.num_columns):
                c = self.grid[row][col]
                if c:
                    yield c
                
    def random_cell(self):
        ''' Chose one of the cells in an independent, uniform distribution. '''
        all_cells = list(self.each_cell())
        return random.choice(all_cells)
        
    def size(self):
        ''' How many cells are in the grid? '''
        all_cells = list(self.each_cell())
        return len(all_cells)

    def cell_at(self, row, column):
        ''' Retrieve the cell at a particular row/column index.'''
        if row < 0 or row >= self.num_rows:
            return None
        if column < 0 or column >= self.num_columns:
            return None
        c = self.grid[row][column]
        if c:
            return c
        # row/col is in the middle of a room, need to search out the top/left corner
        row_temp = row
        column_temp = column
        while not self.grid[row_temp][column] or isinstance(self.grid[row_temp][column], Room):
            row_temp -= 1
        while not self.grid[row][column_temp] or isinstance(self.grid[row][column_temp], Room):
            column_temp -= 1
        return self.grid[row_temp + 1][column_temp + 1] 
        
    def make_rooms(self):
        bsp = BSPTree.BSPTree(0, 0, self.num_columns, self.num_rows, 3, 3, None)
        # Walk bsp and make a room in each leaf
        to_visit = [bsp]
        while to_visit:
            node = to_visit.pop(0)
            if node.right:
                to_visit.append(node.right)
            if node.left:
                to_visit.append(node.left)
            if not node.left and not node.right:
                self.make_room(node)
                
    def make_room(self, bsp_node):
        width_ok  = bsp_node.width  > self.min_room_width  + 2 * self.min_room_spacing
        height_ok = bsp_node.height > self.min_room_height + 2 * self.min_room_spacing
        if not width_ok or not height_ok:
            return
        room_x, room_y, room_width, room_height = self.random_room(bsp_node)
        self.insert_room(room_x, room_y, room_width, room_height)

    def insert_room(self, room_x, room_y, room_width, room_height):
        # That's the easy stuff.  Now, need to exterpate cells from the grid and replace
        # them with this room.  
        # This room will live in the grid at it's xy location (upper left).  There will
        # be None objects in the other spaces in the grid where the room occupies.
        
        # 1. Disconnect neighboring cells.  None have been linked yet, but they have
        #    been connected to their neighbors (in this room's space)
        for col in range(room_x, room_x + room_width):
            self.grid[room_y - 1][col].south = None
            self.grid[room_y + room_height][col].north = None
        for row in range(room_y, room_y + room_height):
            self.grid[row][room_x - 1].east = None
            self.grid[row][room_x + room_width].west = None
            
        # 2. Replace all the cells in this range with None objects
        for row in range(room_y, room_y + room_height):
            for col in range(room_x, room_x + room_width):
                self.grid[row][col] = None
                
        # 3. Insert a new Room into the grid
        room = Room(room_y, room_x, room_width, room_height)
        self.grid[room_y][room_x] = room
        
        # 4. Connect room to one neighboring cell on each wall
        neighbor_top_cell = self.grid[room_y - 1][room_x + room.neighbor_index_top]
        room.north = neighbor_top_cell
        neighbor_top_cell.south = room
        neighbor_bottom_cell = self.grid[room_y + room_height][room_x + room.neighbor_index_bottom]
        room.south = neighbor_bottom_cell
        neighbor_bottom_cell.north = room
        neighbor_left_cell = self.grid[room_y + room.neighbor_index_left][room_x - 1]
        room.west = neighbor_left_cell
        neighbor_left_cell.east = room
        neighbor_right_cell = self.grid[room_y + room.neighbor_index_right][room_x + room_width]
        room.east = neighbor_right_cell
        neighbor_right_cell.west = room
                           
    def random_room(self, bsp_node):
        room_width = random.randrange(self.min_room_width, bsp_node.width-2*self.min_room_spacing)
        room_x = random.randrange(self.min_room_spacing, 
                                  bsp_node.width - room_width - self.min_room_spacing)
        room_x += bsp_node.x
        room_height = random.randrange(self.min_room_height, bsp_node.height-2*self.min_room_spacing)
        room_y = random.randrange(self.min_room_spacing, 
                                  bsp_node.height - room_height - self.min_room_spacing)
        room_y += bsp_node.y
        return room_x, room_y, room_width, room_height

    def __str__(self):
        ret_val = 'Grid with rooms:\n'
        for row in range(self.num_rows): 
            ret_val += f'Row: {row}\n'
            for col in range(self.num_columns):
                c = self.grid[row][col]
                if c == None:
                    ret_val += f'  {col} is None\n'
                else:
                    ret_val += f'  {col} is {c}\n'
        return ret_val
                    
class Markup:
    ''' A Markup is a way to add data to a grid.  It is associated with
        a particular grid.
        
        In this case, each cell can have a single object associated with it.
        
        Subclasses could have other stuff, of course
    '''
    
    def __init__(self, grid, default=' '):
        self.grid = grid
        self.marks = {}  # Key: cell, Value = some object
        self.default = default
        
    def reset(self):
        self.marks = {}
        
    def __setitem__(self, cell, value):
        self.marks[cell] = value
        
    def __getitem__(self, cell):
        return self.marks.get(cell, self.default)
        
    def set_item_at(self, row, column, value):
        assert row >= 0 and row < self.grid.num_rows
        assert column >= 0 and column < self.grid.num_columns
        cell = self.grid.cell_at(row, column)
        if cell:
            self.marks[cell]=value
        else:
            raise IndexError
    
    def get_item_at(self, row, column):
        assert row >= 0 and row < self.grid.num_rows
        assert column >= 0 and column < self.grid.num_columns
        cell = self.grid.cell_at(row, column)
        if cell:
            return self.marks.get(cell)
        else:
            raise IndexError
            
    def max(self):
        ''' Return the cell with the largest markup value. '''
        return max(self.marks.keys(), key=self.__getitem__)

    def min(self):
        ''' Return the cell with the largest markup value. '''
        return min(self.marks.keys(), key=self.__getitem__)

class DijkstraMarkup(Markup):
    ''' A markup class that will run Djikstra's algorithm and keep track
        of the distance values for each cell.
    '''

    def __init__(self, grid, root_cell, default=0):
        ''' Execute the algorithm and store each cell's value in self.marks[]
        '''
        super().__init__(grid, default)
        self.marks[root_cell] = 0
        
        frontier = [root_cell]
        
        while frontier:
            new_frontier = []
            
            for c in frontier:
                for l in c.all_links():
                    if l in self.marks:
                        continue
                    self.marks[l] = self.marks.get(c, self.default) + 1
                    new_frontier.append(l)
            frontier = new_frontier
            
    def farthest_cell(self):
        ''' Find the cell with the largest markup value, which will
            be the one farthest away from the root_call.
            
            Returns: Tuple of (cell, distance)
        '''
        fc = max(self.marks.keys(), key=self.__getitem__)
        return [fc, self.marks[fc]]

class ShortestPathMarkup(DijkstraMarkup):
    ''' Given a starting cell and a goal cell, create a Markup that will
        have the shortest path between those two cells marked.
    '''

    def __init__(self, grid, start_cell, goal_cell, 
                 path_marker='*', non_path_marker=' '):
        super().__init__(grid, start_cell)
        
        current = goal_cell
        
        while current != start_cell:
            self.marks[current] = path_marker
            unvisited_neighbors = [n 
                                   for n in current.all_links() 
                                   if self.marks[n] != path_marker
                                  ]
            lowest_neighbor = min(unvisited_neighbors, key=self.__getitem__)
            current = lowest_neighbor
        self.marks[start_cell] = path_marker
        
        # Now, replace all non-path cells with the non_path_marker
        for c in grid.each_cell():
            if self.marks[c] != path_marker:
                self.marks[c] = non_path_marker

class LongestPathMarkup(ShortestPathMarkup):
    ''' Create a markup with the longest path in the graph marked.
        Note: Shortest path is dependent upon the start and target cells chosen.
              This markup is the longest path to be found _anywhere_ in the maze.
    '''

    def __init__(self, grid, path_marker='*', non_path_marker=' '):
        start_cell = grid.random_cell()
        dm = DijkstraMarkup(grid, start_cell)
        farthest, _ = dm.farthest_cell()
        dm = DijkstraMarkup(grid, farthest)
        next_farthest, _ = dm.farthest_cell()   
        super().__init__(grid, farthest, next_farthest, path_marker, non_path_marker)

class ColorizedMarkup(Markup):
    ''' Markup a maze with various colors.  Each value in the markup is
        an RGB triplet.
    '''

    def __init__(self, grid, channel='R'):
        assert channel in 'RGB'
        super().__init__(grid)
        self.channel = channel
        
    def colorize_dijkstra(self, start_row = None, start_column = None):
        ''' Provide colors for the maze based on their distance from
            some cell.  By default, from the center cell.
        '''
        if not start_row:
            start_row = self.grid.num_rows // 2
        if not start_column:
            start_column = self.grid.num_columns // 2
        start_cell = self.grid.cell_at(start_row, start_column)
        dm = DijkstraMarkup(self.grid, start_cell)
        self.intensity_colorize(dm)
                
    def intensity_colorize(self, markup):
        ''' Given a markup of numeric values, colorize based on
            the relationship to the max numeric value.
        '''
        max = markup.max()
        max_value = markup[max]
        for c in self.grid.each_cell():
            cell_value = markup[c]
            intensity = (max_value - cell_value) / max_value
            dark   = round(255 * intensity)
            bright = round(127 * intensity) + 128
            if self.channel == 'R':
                self.marks[c] = [bright, dark, dark]
            elif self.channel == 'G':
                self.marks[c] = [dark, bright, dark]
            else:
                self.marks[c] = [dark, dark, bright]   
                                       
def binary_tree(grid):
    ''' The Binary Tree Algorithm.
      
        This algorithm works by visiting each cell and randomly choosing
        to link it to the cell to the east or the cell to the north.
        If there is no cell to the east, then always link to the north
        If there is no cell to the north, then always link to the east.
        Except if there are no cells to the north or east (in which case
        don't link it to anything.)
    '''
    for c in grid.each_cell():
        if not c.north and not c.east:
            continue
        if not c.north:
            c.link(c.east)
            continue
        if not c.east:
            c.link(c.north)
            continue
        r = random.choice([c.north, c.east])
        c.link(r)
            
def sidewinder(grid, odds=.5):
    ''' The Sidewinder algorithm.
    
        Considers each row, one at a time.
        For each row, start with the cell on the west end and an empty list 
        (the run).  Append the cell to the run list.
        Choose a random number between 0 and 1.  If it is greater 
        than the odds parameter, then add the eastern cell to the run list and
        link it to the current cell.  That eastern cell then becomes the 
        current cell.
        If the random number was less than the odds parameter, then you are
        done with the run.  Choose one of the cells in the run and link it to 
        the cell to the north.
        
        Be careful, these instructions don't cover the cases where the row
        is the northernmost one (which will need to be a single, linked run) 
        or for cells at the far east (which automatically close the run)
    '''
    assert odds >= 0.0
    assert odds < 1.0    
    for row in grid.each_row():
        run = []
        for cell in row:
            run.append(cell)
            should_close = (cell.east == None)
            if cell.north:
                r = random.random()
                if r < odds:
                    should_close = True
            if should_close:
                link_from = random.choice(run)
                if link_from.north:
                    link_from.link(link_from.north)
                run = []
            else:
                cell.link(cell.east)   
                
def aldous_broder(grid):
    ''' The Aldous-Broder algorithm is a random-walk algorithm.
    
        Start in a random cell.  Choose a random direction.  If the cell
        in that direction has not been visited yet, link the two cells.
        Otherwise, don't link.
        Move to that randomly chosen cell, regardless of whether it was
        linked or not.
        Continue until all cells have been visited.
    '''
    current   = grid.random_cell()
    unvisited = grid.size() - 1
    iteration_count = 0
    
    while unvisited:
        rand_neighbor = random.choice(current.neighbors())
        if rand_neighbor.link_count() == 0:
            unvisited -= 1
            current.link(rand_neighbor)
        current = rand_neighbor
        iteration_count += 1
    print(f'Aldous-Broder executed on a grid of size {grid.size()} in {iteration_count} steps.')
    
def wilson(grid):
    ''' Wilson's algorithm is a random-walk algorithm.
    
        1) Choose a random cell.  Mark it visited.
        2) Choose a random unvisited cell (note, this will necessarily not be the 
          same cell from step 1).  Perform a "loop-erased" random walk until
          running into a visited cell.  The cells chosen during this random
          walk are not yet marked as visited.
        3) Add the path from step 2 to the maze.  Mark all of the cells as visited.
          Connect all the cells from the path, one to each other, and to the 
          already-visited cell it ran into.
        4) Repeat steps 2 and 3 until all cells are visited.
        
        Great.  But, what is a "loop-erased" random walk?  At each step, one 
        random neighbor gets added to the path (which is kept track
        of in order).  Then, check if the neighbor is already in the path.  If 
        so, then the entire loop is removed from the path.  So, if the 
        path consisted of cells at locations (0,0), (0,1), (0,2), (1,2), (1,3),
        (2,3), (2,2), and the random neighbor is (1,2), then there is a loop.
        Chop the path back to (0,0), (0,1), (0,2), (1,2) and continue 
        
        BTW, it  may be easier to manage a  list of unvisited cells, which 
        makes it simpler to choose a random unvisited cell, for instance.   
    '''
    # Make a list of all cells (they are all unvisited)
    unvisited = list(grid.each_cell())

    # Choose one random cell and remove it from the list
    random_choices = 1
    loops_removed = 0
    first = random.choice(unvisited)
    unvisited.remove(first)
    
    # Repeat until the list is empty
    while unvisited:
        # Choose a random cell.  Place it in a list that will be the path
        cell = random.choice(unvisited)
        random_choices += 1
        path = [cell]
        
        # Repeat until the chosen cell is not in the unvisited list
        while cell in unvisited:
            # Choose a new random cell
            cell = random.choice(cell.neighbors())
            random_choices += 1
            # Does the new cell exist in the path list somewhere?
            if cell in path:
                # If yes, remove all cells _AFTER_ it on the path list
                index = path.index(cell)
                path = path[:index+1]
                loops_removed += 1
            else:
                # If no, add the new cell to the end of the list
                path.append(cell)
        
        # Link each cell in the path list to the cell after it in the list               
        first = path.pop(0)
        unvisited.remove(first)
        while path:
            first.link(path[0])
            first = path.pop(0)
            if path:
                 unvisited.remove(first)
                 
    print(f'Wilson executed on a grid of size {grid.size()} with {random_choices}', end='')
    print(f' random cells choosen and {loops_removed} loops removed')
            
def recursive_backtracker(grid, cell=None):
    if not cell:
        cell = grid.random_cell()
        
    #choose a random, unvisited (i.e. unlinked to anyone) neighbor        
    uv_neighbors = [n 
                    for n in cell.neighbors()
                    if n.link_count() == 0
                   ]
    while uv_neighbors:
        neighbor = random.choice(uv_neighbors)
        cell.link(neighbor)
        recursive_backtracker(grid, neighbor)
        uv_neighbors = [n 
                        for n in cell.neighbors()
                        if n.link_count() == 0
                       ]
        
    
        