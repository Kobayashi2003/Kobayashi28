#! /usr/bin/env python3
''' Show off BSP Tree algorithms. '''
import pygame, random

def main():
    display_width  = 1024
    display_height = 768
    display_margin = 5
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('BSP Trees: Example 0')

    iteration_depth = 2
    bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                  display_height-2*display_margin, iteration_depth)
    stats_font = pygame.font.SysFont(['helvetica'], 18)
    stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))

    mouse = False
    clock = pygame.time.Clock()  
    while True:
        clock.tick(60)
        quit, print_it, new_it, plus, minus, mouse = check_events(mouse)
        if quit:
            break            
        if print_it:
            bsp.print_it(iteration_depth)
        if plus:
            iteration_depth += 1
            print(f'Iteration depth increased to {iteration_depth}')
        if minus:
            iteration_depth = max(0, iteration_depth - 1)
            print(f'Iteration depth decreased to {iteration_depth}')
        if new_it:
            bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                          display_height-2*display_margin, iteration_depth)
            stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', 
                                           True, (255,0,0))
            
        screen.fill((0,0,0))
        bsp.draw(screen, mouse)
        screen.blit(stats_surf,(display_margin+1, display_margin+1))
        pygame.display.flip()            

class BSPTree:

    def __init__(self, x, y, width, height, iterations):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)
        self.iteration_depth = iterations
        self.left = self.right = None
        if iterations > 0:
            self.split(iterations)

    def split(self, iterations):
        if self.width < 4 and self.height < 4:
            return  # too small to split
        if random.random() < .5 and self.width >= 4:
            leftup = random.randrange(self.width)
            vertical = True
        elif self.height >= 4:
            leftup = random.randrange(self.height)
            vertical = False
        else:
            leftup = random.randrange(self.width)
            vertical = True
        self.left, self.right = self.make_siblings(vertical, leftup, iterations - 1)
        
    def make_siblings(self, vertical, leftup, iterations):
        if vertical:
            left  = BSPTree(self.x, self.y, leftup, self.height, iterations)
            right = BSPTree(self.x + leftup, self.y, self.width - leftup, self.height, iterations)
        else:
            left  = BSPTree(self.x, self.y, self.width, leftup, iterations)
            right = BSPTree(self.x, self.y + leftup, self.width, self.height-leftup, iterations)
        return left, right
        
    def draw(self, surface, pos):
        pygame.draw.rect(surface, (0,0,255), self.rect, width=1)
        if self.left:
            self.left.draw(surface, pos)
        if self.right:
            self.right.draw(surface, pos)
        if not self.right and not self.left and pos:
            if self.rect.collidepoint(pos):
                pygame.draw.rect(surface, (255, 0, 0), self.rect)
    
    def print_it(self, total_iterations):
        indent = '  ' * (total_iterations - self.iteration_depth)
        print(f'{indent}BSPTree({self.x}, {self.y}, {self.width}, {self.height})')
        if self.left:
            self.left.print_it(total_iterations)
        if self.right:
            self.right.print_it(total_iterations)
    
def check_events(mouse):
    ''' A controller of sorts.  Looks for Quit, several simple events.
        Returns: True/False for if a Quit event happened.
    '''
    
    quit, print_it, new_it, plus, minus = [False] * 5
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                quit = True
            if event.key == pygame.K_ESCAPE:
                quit = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_p:
                print_it = True
            if event.key == pygame.K_a:
                plus = True
            if event.key == pygame.K_z:
                minus = True
            if event.key == pygame.K_n:
                new_it = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            mouse = False
                
    return quit, print_it, new_it, plus, minus, mouse
            
if __name__ == "__main__":
    main()