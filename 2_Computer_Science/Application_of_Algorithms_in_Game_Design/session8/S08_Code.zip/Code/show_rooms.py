#! /usr/bin/env python3
''' Show off mazes and their algorithms. '''
import pygame
import pygame.gfxdraw
import billdraw
from pygame.locals import *
import roomedmazes

def main():
    cell_width  = 16
    cell_height = 16
    cell_inset  = 3
    display_margin = 5
    grid_rows = 48
    grid_cols = 64
    display_width  = grid_cols * cell_width  + 2 * display_margin
    display_height = grid_rows * cell_height + 2 * display_margin
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('Mazes with Rooms!')
    running = True
    markup = None
    g = roomedmazes.Grid_with_Rooms(grid_rows, grid_cols, 4, 6, 3)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                x,y = event.pos
                click_row = (y - display_margin) // cell_height
                click_col = (x - display_margin) // cell_width
                c = g.cell_at(click_row, click_col)
                print(c.extended_str())
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == K_q:  # Quit
                    running = False
                elif event.key == K_n:  # New
                    g = roomedmazes.Grid_with_Rooms(grid_rows, grid_cols, 4, 6, 3)
                    markup = None
                elif event.key == K_f:  # Save to FILE
                    pygame.image.save(screen, 'maze.png')
                elif event.key == K_b:  # Binary Tree
                    roomedmazes.binary_tree(g)
                    markup = None
                elif event.key == K_s:  # Sidewinder
                    roomedmazes.sidewinder(g,.5)
                    markup = None
                elif event.key == K_a:  # Aldous-Broder random walk
                    roomedmazes.aldous_broder(g)
                    markup = None
                elif event.key == K_w:  # Wilson
                    roomedmazes.wilson(g)
                    markup = None
                elif event.key == K_t:  # Braided with a T
                    g.braid()
                elif event.key == K_y:  # Why braid all?  only 60%
                    g.braid(prob=.6)
                elif event.key == K_o:
                    if isinstance(g, roomedmazes.Grid_with_Rooms):
                        g.make_rooms()
                elif event.key == K_l:  # longest path
                    markup = roomedmazes.LongestPathMarkup(g)
                elif event.key == K_d:  # deadend count and color
                    m = roomedmazes.Markup(g, default=0)
                    num_deads = len(g.deadends())
                    print(f'There are {num_deads} deadends')
                    if num_deads > 0:
                        for c in g.deadends():
                            m[c] = 1
                        markup = roomedmazes.ColorizedMarkup(g)
                        markup.intensity_colorize(m)
                elif event.key == K_c:  # Colorize a Dijkstra from the center
                    markup = roomedmazes.ColorizedMarkup(g, channel='G')
                    markup.colorize_dijkstra()
        display_grid(g, markup, screen, cell_width, cell_height, display_margin)
        pygame.display.flip()            

def draw_room_without_inset(room, screen, fill_color, wall_color,
                            room_x, room_y, cell_width, cell_height):
    if not room.north or not room.is_linked(room.north):
        billdraw.hline(screen, wall_color, (room_x, room_y), room.width*cell_width-1)
    else:
        billdraw.hline_gapped(screen, wall_color, (room_x, room_y), 
                              start_length = room.neighbor_index_top*cell_width,
                              gap_length   = cell_width,
                              end_length   = (room.width-room.neighbor_index_top-1) * cell_width-1)

    if not room.south or not room.is_linked(room.south):
        billdraw.hline(screen, wall_color, 
                       point  = (room_x, room_y + room.height * cell_width-1), 
                       length = room.width*cell_width-1)
    else:
        billdraw.hline_gapped(screen, wall_color, 
                              point  = (room_x, room_y + room.height * cell_width-1), 
                              start_length = room.neighbor_index_bottom * cell_width,
                              gap_length   = cell_width,
                              end_length   = (room.width-room.neighbor_index_bottom-1) * cell_width-1)
                            
    if not room.west or not room.is_linked(room.west):
        billdraw.vline(screen, wall_color, 
                       point  = (room_x, room_y), 
                       length = room.height * cell_height-1)
    else:
        billdraw.vline_gapped(screen, wall_color, 
                              point  = (room_x, room_y), 
                              start_length = room.neighbor_index_left * cell_height,
                              gap_length   = cell_height,
                              end_length   = (room.height-room.neighbor_index_left-1) * cell_height-1)
                            
    if not room.east or not room.is_linked(room.east):
        billdraw.vline(screen, wall_color, 
                       point  = (room_x + room.width * cell_height-1, room_y), 
                       length = room.height * cell_height-1)
    else:
        billdraw.vline_gapped(screen, wall_color, 
                              point  = (room_x + room.width * cell_height-1, room_y), 
                              start_length = room.neighbor_index_right * cell_height,
                              gap_length   = cell_height,
                              end_length   = (room.height-room.neighbor_index_right-1) * cell_height-1)
                            
def draw_cell_without_inset(cell, screen, fill_color, wall_color, 
                            cell_x, cell_y, cell_width, cell_height):
    if isinstance(cell, roomedmazes.Room):
        draw_room_without_inset(cell, screen, fill_color, wall_color, 
                                cell_x, cell_y, cell_width, cell_height)
        return
    if not cell.north or not cell.is_linked(cell.north):
        pygame.gfxdraw.hline(screen, 
                             cell_x, cell_x+cell_width-1, cell_y, 
                             wall_color)
    if not cell.south or not cell.is_linked(cell.south):
        pygame.gfxdraw.hline(screen, 
                             cell_x, cell_x+cell_width-1, cell_y+cell_height-1, 
                             wall_color)
    if not cell.east or not cell.is_linked(cell.east):
        pygame.gfxdraw.vline(screen, 
                             cell_x+cell_width-1, cell_y, cell_y+cell_height-1, 
                             wall_color)
    if not cell.west or not cell.is_linked(cell.west):
        pygame.gfxdraw.vline(screen, 
                             cell_x, cell_y, cell_y+cell_height-1, 
                             wall_color)
    if fill_color:
        inside_rect = pygame.Rect(cell_x+1, cell_y+1, cell_width-2, cell_height-2)
        pygame.draw.rect(screen, fill_color, inside_rect)

def cell_coordinates_with_inset(x, y, cell_width, cell_height, inset_size):
    x1 = x
    x2 = x + inset_size
    x4 = x + cell_width - 1
    x3 = x4-inset_size
    
    y1 = y
    y2 = y + inset_size
    y4 = y + cell_height - 1
    y3 = y4 - inset_size
    
    return (x1, x2, x3, x4, y1, y2, y3, y4)
    
def draw_cell_with_inset(cell, screen, fill_color, wall_color, 
                         cell_x, cell_y, cell_width, cell_height, inset_size):
    ''' A more stylish way to draw the cell with a 3-pixel inset in each cell.
    '''
    x1, x2, x3, x4, y1, y2, y3, y4 = cell_coordinates_with_inset(cell_x, cell_y, 
                                                                 cell_width, cell_height, 
                                                                 inset_size)
    
    if not cell.north or not cell.is_linked(cell.north):
        pygame.gfxdraw.hline(screen, x2, x3, y2, wall_color)
    else:
        pygame.gfxdraw.vline(screen, x2, y1, y2, wall_color)
        pygame.gfxdraw.vline(screen, x3, y1, y2, wall_color)
        if fill_color:
            r = pygame.Rect(x2+1, y1, x3-x2-1, y2-y1+1)
            pygame.draw.rect(screen, fill_color, r)

    if not cell.east or not cell.is_linked(cell.east):
        pygame.gfxdraw.vline(screen, x3, y2, y3, wall_color)
    else:
        pygame.gfxdraw.hline(screen, x3, x4, y2, wall_color)
        pygame.gfxdraw.hline(screen, x3, x4, y3, wall_color)
        if fill_color:
            r = pygame.Rect(x3, y2+1, x4-x3+1, y3-y2-1)
            pygame.draw.rect(screen, fill_color, r)

    if not cell.south or not cell.is_linked(cell.south):
        pygame.gfxdraw.hline(screen, x2, x3, y3, wall_color)
    else:
        pygame.gfxdraw.vline(screen, x2, y3, y4, wall_color)
        pygame.gfxdraw.vline(screen, x3, y3, y4, wall_color)
        if fill_color:
            r = pygame.Rect(x2+1, y3, x3-x2-1, y4-y3+1)
            pygame.draw.rect(screen, fill_color, r)

    if not cell.west or not cell.is_linked(cell.west):
        pygame.gfxdraw.vline(screen, x2, y2, y3, wall_color)
    else:
        pygame.gfxdraw.hline(screen, x1, x2, y2, wall_color)
        pygame.gfxdraw.hline(screen, x1, x2, y3, wall_color)
        if fill_color:
            r = pygame.Rect(x1, y2+1, x2-x1+1, y3-y2-1)
            pygame.draw.rect(screen, fill_color, r)
            
    if fill_color:
        r = pygame.Rect(x2+1, y2+1, x3-x2-1, y3-y2-1)
        pygame.draw.rect(screen, fill_color, r)


def display_grid(g, markup, screen, cell_width, cell_height, display_margin):
    if isinstance(markup, roomedmazes.ColorizedMarkup):
        wall_color = (0,0,0)
    else:
        wall_color = (100,100,100)
    screen.fill((0,0,0))
    for cell in g.each_cell():
        cell_x = cell.column * cell_width + display_margin
        cell_y = cell.row * cell_height + display_margin
        fill_color = None
        # Draw top row
        if markup:
            value = markup.get_item_at(cell.row, cell.column)
            if not value:
                continue
            if value == '*':  # Path marker
                pygame.draw.circle(screen,
                                   (150,80,50),
                                   (cell_x+8,cell_y+8),
                                   5,  #radius
                                   0)  #filled
            if isinstance(value, list) and len(value) == 3:
                fill_color = value
        draw_cell_without_inset(cell, screen, fill_color, wall_color, 
                                cell_x, cell_y, cell_width, cell_height)
#             draw_cell_with_inset(cell, screen, fill_color, wall_color, cell_x, cell_y)
            
if __name__ == "__main__":
    main()