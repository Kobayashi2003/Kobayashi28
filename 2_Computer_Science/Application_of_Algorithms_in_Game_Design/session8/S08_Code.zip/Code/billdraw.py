import pygame
import pygame.gfxdraw

def hline(surface, color, point, length):
    assert len(color) == 3
    assert len(point) == 2
    pygame.gfxdraw.hline(surface,
                         point[0], point[0] + length, point[1],
                         color)
                         
def vline(surface, color, point, length):
    assert len(color) == 3
    assert len(point) == 2
    pygame.gfxdraw.vline(surface,
                         point[0], point[1], point[1] + length,
                         color)
                         
def hline_gapped(surface, color, point, start_length, gap_length, end_length):
    assert len(color) == 3
    assert len(point) == 2
    hline(surface, color, point, start_length)
    gap_end_x = point[0] + start_length + gap_length
    hline(surface, color, (gap_end_x, point[1]), end_length)
    
def vline_gapped(surface, color, point, start_length, gap_length, end_length):
    assert len(color) == 3
    assert len(point) == 2
    vline(surface, color, point, start_length)
    gap_end_y = point[1] + start_length + gap_length
    vline(surface, color, (point[0], gap_end_y), end_length)