#! /usr/bin/env python3
''' Show off BSP Tree algorithms. '''
import pygame, random
from pathlib import Path

def main():
    display_width  = 1024
    display_height = 768
    display_margin = 5
    min_room_width = 52
    min_room_height = 52
    min_room_spacing = 30
    min_leaf_width = min_room_width * 2
    min_leaf_height = min_room_height * 2
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('BSP Trees: With Fancy Rooms and Hallways!')
   
    iteration_depth = 2
    bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                  display_height-2*display_margin, iteration_depth, iteration_depth, None)

    stats_font = pygame.font.SysFont(['helvetica'], 18)
    stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))
    
    mouse = False
    while True:
        quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse = check_events(mouse)
        if quit:
            break            
        if print_it:
            bsp.print_it(iteration_depth)
        if plus:
            iteration_depth += 1
        if minus:
            iteration_depth = max(0, iteration_depth - 1)
        if new_it:
            bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                          display_height-2*display_margin, iteration_depth, iteration_depth, None)
            stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))
        if rooms and not bsp.has_room:
            bsp.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if newmouse:
            bsp.debug(mouse)
        if hallways:
            bsp.generate_hallways()
                           
        screen.fill((0,0,0))
        bsp.draw(screen)
        screen.blit(stats_surf,(display_margin+1, display_margin+1))
        pygame.display.flip()            

class Hallway:

    def __init__(self, side, door_x, door_y, end_x, end_y):
        # Hallways are 10 pixel wide rectangles.
        # End_x and end_y are x_y of the center of the splitting segment.  Should be the
        # center of the last rectangle
        self.rects = []
        if side == BSPTree.SIDE_BOTTOM:
            self.rects.append(pygame.Rect(door_x, door_y + 10, 10, 10))
            if door_x < end_x-5:
                mid_len = (end_x + 5) - (door_x)
                self.rects.append(pygame.Rect(door_x, door_y + 20, mid_len, 10))
            else:
                mid_len = (door_x + 10) - (end_x - 5)
                self.rects.append(pygame.Rect(end_x - 5, door_y + 20, mid_len, 10))
            self.rects.append(pygame.Rect(end_x-5, door_y + 30, 10, end_y - door_y - 30))
        elif side == BSPTree.SIDE_TOP:
            self.rects.append(pygame.Rect(door_x, door_y - 10, 10, 10))
            if door_x < end_x-5:
                mid_len = (end_x + 5) - (door_x)
                self.rects.append(pygame.Rect(door_x, door_y - 20, mid_len, 10))
            else:
                mid_len = (door_x + 10) - (end_x - 5)
                self.rects.append(pygame.Rect(end_x - 5, door_y - 20, mid_len, 10))
            self.rects.append(pygame.Rect(end_x-5, end_y, 10, door_y - end_y - 20))
        elif side == BSPTree.SIDE_LEFT:
            self.rects.append(pygame.Rect(door_x-10, door_y, 10, 10))
            if door_y < end_y-5:
                mid_len = (end_y + 5) - (door_y)
                self.rects.append(pygame.Rect(door_x-20, door_y, 10, mid_len))
            else:
                mid_len = (door_y + 10) - (end_y - 5)
                self.rects.append(pygame.Rect(door_x - 20, end_y - 5, 10, mid_len))
            self.rects.append(pygame.Rect(end_x, end_y - 5, door_x - 20 - end_x, 10))
        elif side == BSPTree.SIDE_RIGHT:
            self.rects.append(pygame.Rect(door_x+10, door_y, 10, 10))
            if door_y < end_y-5:
                mid_len = (end_y + 5) - (door_y)
                self.rects.append(pygame.Rect(door_x+20, door_y, 10, mid_len))
            else:
                mid_len = (door_y + 10) - (end_y - 5)
                self.rects.append(pygame.Rect(door_x + 20, end_y - 5, 10, mid_len))
            self.rects.append(pygame.Rect(door_x + 30, end_y - 5, end_x - door_x - 30, 10))
        else:
            print("OOOps.  Hallway.init")
        self.door_x = door_x
        self.door_y = door_y
        self.end_x = end_x
        self.end_y = end_y
        
    def draw(self, surface):
        for rect in self.rects:
            pygame.draw.rect(surface, (70,0,0), rect)
    
class Room:

    floor_surf = None
    
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        if not Room.floor_surf:
            current_directory = Path('.')
            Room.floor_surf = pygame.image.load(current_directory / 
                                                'assets' / 'floor.png')
            Room.vert_surf  = pygame.image.load(current_directory / 
                                                'assets' / 'wall_vertical.png')
            Room.horiz_surf = pygame.transform.rotate(Room.vert_surf, 90)
        self.door_rect = None
                        
    def draw(self, surface):
        self.draw_floor(surface)
        self.draw_walls(surface)
        self.draw_doors(surface)
        
    def draw_floor(self, surface):
        for x in range(self.rect.left + 10, self.rect.right - 10 - 31, 32):
            for y in range(self.rect.top + 10, self.rect.bottom - 10 - 31, 32):
                surface.blit(Room.floor_surf, (x, y))
            # clean up bottom row
            ytiles,yremain = divmod(self.rect.height - 20, 32)
            yrect = pygame.Rect(0, 0, 32, yremain)
            y = self.rect.top + 10 + ytiles * 32
            surface.blit(Room.floor_surf, (x,y), yrect)
        # clean up last column
        xtiles, xremain = divmod(self.rect.width - 20, 32)
        xrect = pygame.Rect(0, 0, xremain, 32)
        xlast_rect = pygame.Rect(0, 0, xremain, yremain)
        ylast_row  = y
        x = self.rect.left + 10 + xtiles * 32
        for y in range(self.rect.top + 10, self.rect.bottom - 10 - 31, 32):
            surface.blit(Room.floor_surf, (x, y), xrect)
        surface.blit(Room.floor_surf, (x, ylast_row), xlast_rect)
 
    def draw_walls(self, surface):
        self.draw_horizontal_walls(surface, self.rect.top)
        self.draw_horizontal_walls(surface, self.rect.bottom - 10)
        self.draw_vertical_walls(surface, self.rect.left)
        self.draw_vertical_walls(surface, self.rect.right - 10)
        
    def draw_horizontal_walls(self, surface, y):
        # Wall segment size is 10 x 35
        num_tiles, remaining = divmod(self.rect.width, 35)
        x = self.rect.left
        for _ in range(num_tiles):
            surface.blit(Room.horiz_surf, (x, y))
            x += 35
        rem_rect = pygame.Rect(0,0,remaining,10)
        surface.blit(Room.horiz_surf, (x, y), rem_rect)
        
    def draw_vertical_walls(self, surface, x):
        # Wall segment size is 10 x 35
        num_tiles, remaining = divmod(self.rect.height - 20, 35)
        y = self.rect.top + 10
        for _ in range(num_tiles):
            surface.blit(Room.vert_surf, (x, y))
            y += 35
        rem_rect = pygame.Rect(0,0,10,remaining)
        surface.blit(Room.vert_surf, (x, y), rem_rect)

    def set_door_random(self, side):
        # narrow doors are 10 pixels wide and must be at least 8 pixels from the nearest edge
        if self.rect.width  <= 52 and (side == BSPTree.SIDE_TOP or side == BSPTree.SIDE_BOTTOM):
            door_width = 10
            door_margin = 8
        elif self.rect.height <= 52 and (side == BSPTree.SIDE_LEFT or side == BSPTree.SIDE_RIGHT):
            door_width = 10
            door_margin = 8
        else:
            door_width = 10
            door_margin = 16
        if side == BSPTree.SIDE_RIGHT:
            distance = random.randrange(10+door_margin, self.rect.height - 10 - door_margin)
            self.door_rect = pygame.Rect(self.rect.width - 10, distance, 10, door_width)
        elif side == BSPTree.SIDE_LEFT:
            distance = random.randrange(10+door_margin, self.rect.height - 10 - door_margin)
            self.door_rect = pygame.Rect(0, distance, 10, door_width)
        elif side == BSPTree.SIDE_TOP:
            distance = random.randrange(10+door_margin, self.rect.width - 10 - door_margin)
            self.door_rect = pygame.Rect(distance, 0 , door_width, 10)
        elif side == BSPTree.SIDE_BOTTOM:
            distance = random.randrange(10+door_margin, self.rect.width - 10 - door_margin)
            self.door_rect = pygame.Rect(distance, self.rect.height - 10 , door_width, 10)
        else:
            print("oops in set_door_random")
        self.door_rect.move_ip(self.rect.x, self.rect.y)

    def draw_doors(self, surface):
        if self.door_rect:
            pygame.draw.rect(surface, (112, 62, 0), self.door_rect)       
                
    def __str__(self):
        return f'Room at {self.rect}'
                
class BSPTree:

    SIDE_LEFT = 1
    SIDE_RIGHT = 2
    SIDE_TOP = 3
    SIDE_BOTTOM = 4
        
    def __init__(self, x, y, width, height, iterations, max_iterations, split_side):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)
        self.iteration_depth = iterations
        self.left = self.right = None
        self.room = self.hallway = None
        self.has_room = False
        if iterations > 0:
            self.split(iterations, max_iterations)
        self.split_side = split_side  # which side is towards my level-neighbor
            
    def debug(self, pos):
        if self.rect.collidepoint(pos):
            if not self.left and not self.right:
                print(f'{self.room}')
            if self.left:
                self.left.debug(pos)
            if self.right:
                self.right.debug(pos)
                
    def generate_hallways(self):
        if self.left:
            self.left.generate_hallways()
        if self.right:
            self.right.generate_hallways()
        if self.room:
            self.room.set_door_random(self.split_side)
            if self.split_side == BSPTree.SIDE_RIGHT:
                end_x = self.rect.right
                end_y = (self.rect.top + self.rect.bottom)//2
            elif self.split_side == BSPTree.SIDE_LEFT:
                end_x = self.rect.left
                end_y = (self.rect.top + self.rect.bottom)//2
            elif self.split_side == BSPTree.SIDE_TOP:
                end_x = (self.rect.left + self.rect.right) // 2
                end_y = self.rect.top
            elif self.split_side == BSPTree.SIDE_BOTTOM:
                end_x = (self.rect.left + self.rect.right) // 2
                end_y = self.rect.bottom
            else:
                print("oops.  Generate Hallways")
            self.hallway = Hallway(self.split_side, 
                                   self.room.door_rect.x, self.room.door_rect.y,
                                   end_x, end_y)
            
    def generate_rooms(self, min_room_width, min_room_height, min_room_spacing):
        if self.left:
            self.left.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if self.right:
            self.right.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if not self.left and not self.right:
            self.build_my_room(min_room_width, min_room_height, min_room_spacing)
        
    def build_my_room(self, min_room_width, min_room_height, min_room_spacing):
        width_ok  = self.width  > min_room_width  + 2 * min_room_spacing
        height_ok = self.height > min_room_height + 2 * min_room_spacing
        if width_ok and height_ok:
            room_width = random.randrange(min_room_width, self.width-2*min_room_spacing)
            room_x = random.randrange(min_room_spacing, 
                                      self.width-room_width - min_room_spacing)
            room_x += self.x
            room_height = random.randrange(min_room_height, self.height-2*min_room_spacing)
            room_y = random.randrange(min_room_spacing, 
                                      self.height-room_height - min_room_spacing)
            room_y += self.y
            self.room = Room(room_x, room_y, room_width, room_height)
            self.has_rooms = True

    def split(self, iterations, max_iterations):
        if iterations < max_iterations *.75 and random.random() < .1:
            return
        if self.width / self.height > 1.25:
            split_vertical = True
        elif self.height / self.width > 1.25:
            split_vertical = False
        else:
            split_vertical = random.random() < .5
            
        ratio_limit = .35
        if split_vertical:
            lower_w = round(self.width * ratio_limit)
            upper_w = round(self.width * (1-ratio_limit))
            w = random.randrange(lower_w, upper_w)
            self.left, self.right = self.make_siblings(True, w, iterations - 1, max_iterations)
        else:
            lower_h = round(self.height * ratio_limit)
            upper_h = round(self.height * (1-ratio_limit))
            h = random.randrange(lower_h, upper_h)
            self.left, self.right = self.make_siblings(False, h, iterations - 1, max_iterations)
                    
    def make_siblings(self, vertical, leftup, iterations, max_iterations):
        if vertical:
            left  = BSPTree(self.x, self.y, leftup, self.height, 
                            iterations, max_iterations, BSPTree.SIDE_RIGHT)
            right = BSPTree(self.x + leftup, self.y, self.width - leftup, self.height, 
                            iterations, max_iterations, BSPTree.SIDE_LEFT)
        else:
            left  = BSPTree(self.x, self.y, self.width, leftup, 
                            iterations, max_iterations, BSPTree.SIDE_BOTTOM)
            right = BSPTree(self.x, self.y + leftup, self.width, self.height-leftup, 
                            iterations, max_iterations, BSPTree.SIDE_TOP)
        return left, right
        
    def draw(self, surface):
        pygame.draw.rect(surface, (0,0,255), self.rect, width=1)
        if self.left:
            self.left.draw(surface)
        if self.right:
            self.right.draw(surface)
        if self.room:
            self.room.draw(surface)
#             if self.split_side == BSPTree.SIDE_RIGHT:
#                  pygame.draw.line(surface, (255,0,0), 
#                                   (self.rect.right - 10, self.rect.top), 
#                                   (self.rect.right - 10, self.rect.bottom))
#             elif self.split_side == BSPTree.SIDE_LEFT:
#                  pygame.draw.line(surface, (255,0,0), 
#                                   (self.rect.left + 10, self.rect.top), 
#                                   (self.rect.left + 10, self.rect.bottom))
#             elif self.split_side == BSPTree.SIDE_TOP:
#                  pygame.draw.line(surface, (255,0,0), 
#                                   (self.rect.left,  self.rect.top + 10), 
#                                   (self.rect.right, self.rect.top + 10))
#             elif self.split_side == BSPTree.SIDE_BOTTOM:
#                  pygame.draw.line(surface, (255,0,0), 
#                                   (self.rect.left,  self.rect.bottom - 10), 
#                                   (self.rect.right, self.rect.bottom - 10))
#             else:
#                 print("oops!  in BSPTree.draw")
            if self.hallway:
                self.hallway.draw(surface)
                
    def print_it(self, total_iterations):
        indent = '  ' * (total_iterations - self.iteration_depth)
        print(f'{indent}{self}')
        if self.left:
            self.left.print_it(total_iterations)
        if self.right:
            self.right.print_it(total_iterations)
            
    def __str__(self):
        ret_val = f'BSPTree({self.x}, {self.y}, {self.width}, {self.height}'
        if self.left and self.right:
            ret_val += f', LR'
        elif self.left:
            ret_val += f', L'
        elif self.right:
            ret_val += f', R'
        
        if self.has_room:
            ret_val += ', Room({self.room_rect})'

        ret_val += ')'        
        return ret_val
    
def check_events(mouse):
    ''' A controller of sorts.  Looks for Quit, several simple events.
        Returns: True/False for if a Quit event happened.
    '''
    
    quit, print_it, new_it, plus, minus, rooms, hallways, newmouse = [False] * 8
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                quit = True
            if event.key == pygame.K_ESCAPE:
                quit = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_p:
                print_it = True
            if event.key == pygame.K_a:
                plus = True
            if event.key == pygame.K_z:
                minus = True
            if event.key == pygame.K_n:
                new_it = True
            if event.key == pygame.K_r:
                rooms = True
            if event.key == pygame.K_h:
                hallways = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            newmouse = mouse = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            mouse = False
                
    return quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse
            
if __name__ == "__main__":
    main()