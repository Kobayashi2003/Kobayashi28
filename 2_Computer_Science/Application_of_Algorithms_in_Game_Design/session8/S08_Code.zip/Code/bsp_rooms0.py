#! /usr/bin/env python3
''' Show off BSP Tree algorithms. '''
import pygame, random

def main():
    display_width  = 1024
    display_height = 768
    display_margin = 5
    min_room_width = 52
    min_room_height = 52
    min_room_spacing = 10
    min_leaf_width = min_room_width * 2
    min_leaf_height = min_room_height * 2
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('BSP Trees: With Rooms!')

    iteration_depth = 2
    bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                  display_height-2*display_margin, iteration_depth, iteration_depth)
    
    stats_font = pygame.font.SysFont(['helvetica'], 18)
    stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))

    mouse = False
    clock = pygame.time.Clock()  
    while True:
        clock.tick(60)
        quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse = check_events(mouse)
        if quit:
            break            
        if print_it:
            bsp.print_it(iteration_depth)
        if plus:
            iteration_depth = min(iteration_depth+1, 14)
        if minus:
            iteration_depth = max(0, iteration_depth - 1)
        if new_it:
            bsp = BSPTree(display_margin, display_margin, display_width-2*display_margin, 
                          display_height-2*display_margin, iteration_depth, iteration_depth)
            stats_surf = stats_font.render(f'Iteration Depth: {iteration_depth}', True, (255,0,0))
        if rooms and not bsp.has_room:
            bsp.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if newmouse:
            bsp.debug(mouse)
                           
        screen.fill((0,0,0))
        bsp.draw(screen)
        screen.blit(stats_surf,(display_margin+1, display_margin+1))
        pygame.display.flip()            

class Room:

    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
                
    def draw(self, surface):
        pygame.draw.rect(surface, (0,200,200), self.rect, width=1)
                        
    def __str__(self):
        return f'Room at {self.rect}'
                
class BSPTree:

    def __init__(self, x, y, width, height, iterations, max_iterations):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = pygame.Rect(x, y, width, height)
        self.iteration_depth = iterations
        self.left = self.right = None
        self.room = None
        self.has_room = False
        if iterations > 0:
            self.split(iterations, max_iterations)
            
    def debug(self, pos):
        if self.rect.collidepoint(pos):
            if not self.left and not self.right:
                print(f'{self.room}')
            if self.left:
                self.left.debug(pos)
            if self.right:
                self.right.debug(pos)
            
    def generate_rooms(self, min_room_width, min_room_height, min_room_spacing):
        if self.left:
            self.left.generate_rooms(min_room_width, min_room_height, min_room_spacing)
            self.right.generate_rooms(min_room_width, min_room_height, min_room_spacing)
        if not self.left and not self.right:
            self.build_room(min_room_width, min_room_height, min_room_spacing)
        
    def build_room(self, min_room_width, min_room_height, min_room_spacing):
        width_ok  = self.width  > min_room_width  + 2 * min_room_spacing
        height_ok = self.height > min_room_height + 2 * min_room_spacing
        if width_ok and height_ok:
            room_width = random.randrange(min_room_width, self.width-2*min_room_spacing)
            room_x = random.randrange(min_room_spacing, 
                                      self.width-room_width - min_room_spacing)
            room_x += self.x
            room_height = random.randrange(min_room_height, self.height-2*min_room_spacing)
            room_y = random.randrange(min_room_spacing, 
                                      self.height-room_height - min_room_spacing)
            room_y += self.y
            self.room = Room(room_x, room_y, room_width, room_height)
            self.has_rooms = True

    def split(self, iterations, max_iterations):
        if iterations < max_iterations *.75 and random.random() < .1:
            return
        if self.width / self.height > 1.25:
            split_vertical = True
        elif self.height / self.width > 1.25:
            split_vertical = False
        else:
            split_vertical = random.random() < .5
            
        ratio_limit = .35
        r = random.uniform(ratio_limit, 1-ratio_limit)
        if split_vertical:
            split_width = round(r * self.width)
            self.left, self.right = self.make_siblings(True, split_width, iterations - 1, max_iterations)
        else:
            split_height = round(r * self.height)
            self.left, self.right = self.make_siblings(False, split_height, iterations - 1, max_iterations)
                    
    def make_siblings(self, vertical, leftup, iterations, max_iterations):
        if vertical:
            left  = BSPTree(self.x, self.y, leftup, self.height, iterations, max_iterations)
            right = BSPTree(self.x + leftup, self.y, self.width - leftup, self.height, iterations, max_iterations)
        else:
            left  = BSPTree(self.x, self.y, self.width, leftup, iterations, max_iterations)
            right = BSPTree(self.x, self.y + leftup, self.width, self.height-leftup, iterations, max_iterations)
        return left, right
        
    def draw(self, surface):
        pygame.draw.rect(surface, (0,0,255), self.rect, width=1)
        if self.left:
            self.left.draw(surface)
        if self.right:
            self.right.draw(surface)
        if self.room:
            self.room.draw(surface)
                
    def print_it(self, total_iterations):
        indent = '  ' * (total_iterations - self.iteration_depth)
        print(f'{indent}{self}')
        if self.left:
            self.left.print_it(total_iterations)
        if self.right:
            self.right.print_it(total_iterations)
            
    def __str__(self):
        ret_val = f'BSPTree({self.x}, {self.y}, {self.width}, {self.height}'
        if self.left and self.right:
            ret_val += f', LR'
        elif self.left:
            ret_val += f', L'
        elif self.right:
            ret_val += f', R'
        
        if self.has_room:
            ret_val += ', Room({self.room_rect})'

        ret_val += ')'        
        return ret_val
    
def check_events(mouse):
    ''' A controller of sorts.  Looks for Quit, several simple events.
        Returns: True/False for if a Quit event happened.
                 True/False for request to print the BSP Tree data in the terminal.
                 True/False for request to render the BSPTree.
                 True/False for greater iteration depth
                 True/False for lesser iteration depth
                 True/False to draw hallways
                 Position of a mouse press (if newly pressed) or old position (if no press)
    '''
    
    quit, print_it, new_it, plus, minus, rooms, hallways, newmouse = [False] * 8
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                quit = True
            if event.key == pygame.K_ESCAPE:
                quit = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_p:
                print_it = True
            if event.key == pygame.K_a:
                plus = True
            if event.key == pygame.K_z:
                minus = True
            if event.key == pygame.K_n:
                new_it = True
            if event.key == pygame.K_r:
                rooms = True
            if event.key == pygame.K_h:
                hallways = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            newmouse = mouse = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            mouse = False
                
    return quit, print_it, new_it, plus, minus, rooms, hallways, mouse, newmouse
            
if __name__ == "__main__":
    main()