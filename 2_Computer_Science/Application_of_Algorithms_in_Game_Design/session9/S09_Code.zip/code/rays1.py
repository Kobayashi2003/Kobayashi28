#! /usr/bin/env python3
''' Show off Ray Casting algorithms. '''
import pygame, random

def main():
    display_width  = 1024
    display_height = 768
    pygame.init()
    screen = pygame.display.set_mode((display_width, display_height)) 
    pygame.display.set_caption('Ray Casting')

    start = None
    end = None
    line_segments = [((0,0),(display_width-1, 0)),
                     ((0,0),(0, display_height-1)),
                     ((display_width-1,0), (display_width-1, display_height-1)),
                     ((0, display_height-1), (display_width-1, display_height-1)),
                     ]
    line_segment = ((680, 200),(950, 500))           
    while True:
        quit, mouse_down, mouse_up, mouse_move = check_events()
        if quit:
            break
        if mouse_down:
            start = pygame.Vector2(mouse_down)
            end = None
        if mouse_up:
            end = pygame.Vector2(mouse_up)
            vel = end - start
            vel.scale_to_length(700)
            edge0, edge1 = clip_points(start, end, display_width, display_height)
            coll = is_ray_cast_collision(start, end, line_segment)
            if coll:
                print('Collides!')
            else:
                print('Miss!')
                   
            
        screen.fill((0,0,0))
        draw_ball_line_segment(screen, (0,255,255), 3, line_segment[0], line_segment[1])
        if start:
            pygame.draw.circle(screen, (255,255,0), start, 3)
        if end:
            draw_ball_line_segment(screen, (255,255,0), 3, start, end)
            pygame.draw.line(screen, (150, 150, 150), edge0, edge1, 1)
        pygame.display.flip()     

def draw_ball_line_segment(surface, color, radius, point0, point1):
    for point in [point0, point1]:
        pygame.draw.circle(surface, color, point, radius)
    pygame.draw.line(surface, color, point1, point0, 4)
            
def is_ray_cast_collision(start, end, line_segment):
    ''' Given a point, defined as a Vector2 or (x,y), test to see if it intersects
        with the line segment, defined as ((x0,y0), (x1,y1)).
        Return True if it does intersect.
    ''' 
    origin = pygame.math.Vector2(start)
    point_vec = pygame.math.Vector2(end) - origin
    ls_0 = pygame.math.Vector2(line_segment[0]) - origin      
    ls_1 = pygame.math.Vector2(line_segment[1]) - origin 
    rotation = point_vec.angle_to((1,0))
    point_vec.rotate_ip(rotation)
    ls_0.rotate_ip(rotation)
    ls_1.rotate_ip(rotation)
    if ls_0.y < ls_1.y:
        ls_a = ls_0
        ls_b = ls_1
    else:
        ls_a = ls_1
        ls_b = ls_0

#     print(f'Before rotation: start is {start}, end is {end}')
#     print(f'After rotation: vector is {point_vec}, ls0 is {ls_0}, ls1 is {ls_1}')
#     print(f'  ls_a is {ls_a}, ls_b is {ls_b}')
#     print(f'  rotation angle was {rotation}')


    if point_vec.y in [ls_a.y, ls_b.y]:
        point_vec.y += .00005
    if (point_vec.y < ls_a.y or 
        point_vec.y > ls_b.y):
        return False
    if point_vec.x >= max(ls_a.x, ls_b.x):
        return False
    if point_vec.x < min(ls_a.x, ls_b.x):
        return True
    if ls_a.x == ls_b.x:
        ls_slope = 1e10
    else:
        ls_slope = (ls_b.y - ls_a.y) / (ls_b.x - ls_a.x)
    if point_vec.x == ls_a.x:
        point_slope = 1e10
    else:
        point_slope = (point_vec.y - ls_a.y) / (point_vec.x - ls_a.x)
    # Finally!
    if point_slope >= ls_slope:
        return True
    return False
    
         

def m_b_of_line(point0, point1):
    x0, y0 = point0
    x1, y1 = point1
    delx = x1 - x0
    dely = y1 - y0
    if delx == 0:
        m = b = None
    else:
        m = dely / delx
        b = y0 - m*x0  
    return m, b
    
def clip_points(point0, point1, width, height):
    x0, y0 = point0
    x1, y1 = point1
    delx = x1 - x0
    dely = y1 - y0 
    
    case0 = case1 = ''
    
    if delx == 0:
        edge0 = (x0, 0)
        edge1 = (x0, height)
    else:
        m = dely / delx
        b = y0 - m*x0
        if b < 0:
            edge0 = (int(round(-b / m)), 0)  
        elif b > height:
            edge0 = (int(round((height-1-b)/m)), height-1)
        else:
            edge0 = (0, int(round(b)))
        ywid = (width-1) * m + b
        if ywid < 0:
            edge1 = (int(round(-b / m)), 0)
        elif ywid >= height:
            edge1 = (int(round((height - 1 - b)/m)), height - 1)
        else:
            edge1 = (width-1, int(round(ywid)))
    print(f'Edge points are ({edge0[0]},{edge0[1]}) and ({edge1[0]},{edge1[1]})')
    return edge0, edge1
    
def check_events():
    ''' A controller of sorts.  Looks for Quit, several simple events.
        Returns: True/False for if a Quit event happened.
    '''
    
    quit, mouse_down, mouse_up, mouse_move = [False] * 4
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit = True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                quit = True
            if event.key == pygame.K_ESCAPE:
                quit = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_down = event.pos
        if event.type == pygame.MOUSEBUTTONUP:
            mouse_up = event.pos
        if event.type == pygame.MOUSEMOTION:
            mouse_move = event.pos
                
    return quit, mouse_down, mouse_up, mouse_move
            
if __name__ == "__main__":
    main()