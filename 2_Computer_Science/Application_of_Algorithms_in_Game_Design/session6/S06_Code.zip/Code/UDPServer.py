#! /usr/bin/env python3
''' A simple location server for a game.
    Receives movement messages from clients.  
    Sends all clients the positions of all players.
'''
import socket
import select
import sys
import argparse

# Messages:
#  Client->Server
#   One or two characters. First character is the command:
#     c: connect
#     u: update position
#     d: disconnect
#   Second character only applies to position and specifies direction (udlr)
#
#  Server->Client
#   '|' delimited pairs of positions to draw the players (there is no
#     distinction between the players - not even the client knows where its
#     player is.

def arguments():
    parser = argparse.ArgumentParser(description='Be the server for UDP game')
    parser.add_argument('-i', '--ip', default='127.0.0.1', 
                        help='IP address of the server')
    parser.add_argument('-p', '--port', default=9009,
                        help='Port address of the server')
    args = parser.parse_args()
    return args.ip, args.port
    
def main(ip, port):
    listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind to localhost - set to external ip to connect from other computers
    listener.bind((ip,port))
    read_list = [listener]
    write_list = []
    
    stepsize = 5
    players = {}
    
    print("Waiting...")
    try:
      while True:
        readable, writable, exceptional = (
          select.select(read_list, write_list, [])
        )
        for f in readable:
          if f is listener:
            msg, addr = f.recvfrom(32)
            msg = str(msg, 'utf-8')
            if len(msg) >= 1:
              cmd = msg[0]
              if cmd == "c":  # New Connection
                players[addr] = (0,0)
                print(f'New connection from {addr}')
              elif cmd == "u":  # Movement Update
                if len(msg) >= 2 and addr in players:
                  # Second char of message is direction (udlr)
                  movement = msg[1]                  
                  pos = players[addr]
                  if movement == "u":
                    pos = (pos[0], max(0, pos[1] - stepsize))
                  elif movement == "d":
                    pos = (pos[0], min(280, pos[1] + stepsize))
                  elif movement == "l":
                    pos = (max(0, pos[0] - stepsize), pos[1])
                  elif movement == "r":
                    pos = (min(390, pos[0] + stepsize), pos[1])
                  
                  players[addr] = pos
                  print(f'Received {movement} from {addr}')
              elif cmd == "d":  # Player Quitting
                if addr in players:
                    print(f'Disconnection from {addr}')
                    del players[addr]
              else:
                print("Unexpected: {0}".format(msg))
        for player in players:
          send = []
          for pos in players:
            send.append("{0},{1}".format(*players[pos]))
            join_str = '|'.join(send)
            join_bytes = join_str.encode('utf-8')
          listener.sendto(join_bytes, player)
    except KeyboardInterrupt as e:
      pass

if __name__ == "__main__":
  ip, port = arguments()
  main(ip, port)