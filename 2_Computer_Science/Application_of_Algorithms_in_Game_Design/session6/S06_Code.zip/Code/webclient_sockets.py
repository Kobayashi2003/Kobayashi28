#!/usr/bin/env python3
import sys, socket 

# hard-wire the port number for safety's sake 
# then take the names of the host and file from the command line 
port = 80 
host = sys.argv[1] 
filename = sys.argv[2]

FORMAT = "---------------\n{}\n---------------"

# create a TCP/IP socket object 
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
sock.connect((host, port)) 

# Send an HTTP GET request
request = "GET {} HTTP/1.1\nHost: {}\n\n".format(filename, host)
print("\nSending an HTTP Request\n")
print(FORMAT.format(request))
totalsent = 0
while totalsent < len(request):
    bytes_array = request[totalsent:].encode('utf-8')
    sent = sock.send(bytes_array)
    if sent == 0:
        print("connection broken during send")
        sys.exit(-1)
    totalsent += sent

# Read and print out the response
print("\nReading the response\n")
chunks = []
while True:
    chunk = sock.recv(4096)
    if chunk == b'':
        break
    chunks.append(chunk)
byte_array = b''.join(chunks)
response = byte_array.decode('utf-8')
print(FORMAT.format(response))
    
sock.close()
