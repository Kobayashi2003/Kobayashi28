#! /usr/bin/env python3
''' A very simple client.  Sends keystrokes to the server.  Gets
    sprite locations from the server and draws them.
'''
import pygame
import pygame.locals
import socket
import select
import random
import time
import argparse

def arguments():
    parser = argparse.ArgumentParser(description='Be the client for the UDP game')
    parser.add_argument('-i', '--ip', default='127.0.0.1', 
                        help='IP address of the server')
    parser.add_argument('-p', '--port', default=9009,
                        help='Port address of the server')
    parser.add_argument('--local_ip', default='127.0.0.1', 
                        help='IP address of the client')
    parser.add_argument('--local_port',  
                        help='Port address of the client')
    args = parser.parse_args()
    if not args.local_port:
        args.local_port = random.randrange(8000, 8999)
    return args.ip, args.port, args.local_ip, args.local_port

def main(remote_ip, remote_port, local_ip, local_port):

    clientport = random.randrange(8000, 8999)
    conn = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind to localhost - set to external ip to connect from other computers
    conn.bind((local_ip, local_port))
    addr_port = (remote_ip, remote_port)
    
    read_list = [conn]
    write_list = []
    
    pygame.init()
    screen = pygame.display.set_mode((400, 300))
    bg_surface = pygame.image.load("bg.jpg").convert()  
    image = pygame.image.load("sprite.png").convert_alpha()
    
    pygame.key.set_repeat(50, 50)
  
    running = True
    clock = pygame.time.Clock()
    
    try:
      # Initialize connection to server
      conn.sendto(b"c", addr_port)
      while running:
        clock.tick(30)
        
        # select on specified file descriptors
        readable, writable, exceptional = (
            select.select(read_list, write_list, [], 0)  # zero timeout means no waiting
        )
        for f in readable:
          if f is conn:
            msg, addr = f.recvfrom(32)
            msg = str(msg, 'utf-8')
            screen.blit(bg_surface, (0,0))  # Draw the background
            for position in msg.split('|'):
              x, sep, y = position.partition(',')
              try:
                screen.blit(image, (int(x), int(y)))
              except:
                print('Something went wrong')  # If something goes wrong, don't draw anything.
            

        for event in pygame.event.get():
          if event.type == pygame.QUIT or event.type == pygame.locals.QUIT:
            running = False
            break
          elif event.type == pygame.locals.KEYUP:
            if event.key == pygame.locals.K_UP:
              conn.sendto(b"uu", addr_port)
            elif event.key == pygame.locals.K_DOWN:
              conn.sendto(b"ud", addr_port)
            elif event.key == pygame.locals.K_LEFT:
              conn.sendto(b"ul", addr_port)
            elif event.key == pygame.locals.K_RIGHT:
              conn.sendto(b"ur", addr_port)
            elif event.key in [pygame.locals.K_q, pygame.locals.K_ESCAPE]:
              running = False

        pygame.display.update()

    finally:
      conn.sendto(b"d", addr_port)

if __name__ == "__main__":
  remote_ip, remote_port, local_ip, local_port = arguments()
  main(remote_ip, remote_port, local_ip, local_port)