<template>
  <router-view :key="$route.path" />
</template>
