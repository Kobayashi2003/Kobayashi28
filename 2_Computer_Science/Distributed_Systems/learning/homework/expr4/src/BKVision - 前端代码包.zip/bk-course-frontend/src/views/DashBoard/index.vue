<template>
  <div class="DashBoard" style="height: 2000px">
    <iframe
        src="https://apps.ce.bktencent.com/bk-vision/embed/?uid=Y3DMrWptnWf4fMXr6znCvb&bk_app_id=&bk_app_list=['bk-scut-course']&name=&show_copyright=True&watermark=True&time_readonly=False&show_time=True&show_refresh=True&start_time=now/d&end_time=now/d&preview=False&hide_toolbox=False&hide_filter=False&panels=&refresh=False"
        style="height: 100%;width: 100%;border: 1px solid rgb(220, 222, 229);">
    </iframe>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      initDateTime: new Date(),
    };
  },
  created() {
  },
  methods: {
  },
};
</script>
