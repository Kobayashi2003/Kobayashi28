DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": "lesson11",  # noqa
        "USER": "root",
        "PASSWORD": "huan0912",
        "HOST": "localhost",
        "PORT": "3306",
    },
}